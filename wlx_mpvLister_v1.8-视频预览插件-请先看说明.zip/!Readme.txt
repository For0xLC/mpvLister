; 配置文件 mpvLister.ini 使用 utf-8 编码（无签名）
; mpv=mpv.exe的路径，支持相对路径，支持环境变量（自己试试）
; params=mpv启动参数。可以指定--profile=<name>添加插件独立配置段
; mpv64 和 params64 是“.wlx64”版本读取的配置项


; 下方给出两条命令示例，按m切换静音，按CTRL+B设置AB-Loop，可以参照示例编写
; mpv的IPC通信支持两种格式，示例1的JSON格式和示例2的命令格式（见 mpvLister.ini）
; https://mpv.io/manual/stable/#command-interface
; https://mpv.io/manual/stable/#json-ipc 
; 注意：mpv命令中的文件路径需要采用 '/' 而不是Windows默认的 '\'
; 一些按键由Lister主窗口占用，无法使用，如：Alt、C、L、N、P、+、-等
; 未被Lister主窗口占用且未定义的按键，初次按下后将自动写进配置（检验是否被Lister主窗口占用）
; ESC、SPACE、BackSpace、Home、End、PageUP、PageDown、UP、DOWN、LEFT、RIGHT 直接传递给mpv（消息传递）
; 暂时仅支持 <C+字母/字数> 或 <C+S+字母/数字> 或 <字母/数字> 或 <单一以下字符：, . / ; ' \>
; C = Ctrl键, S = Shift键


; 视频缩略图推荐Explorer插件Icaros: https://github.com/Xanashi/Icaros 
; thumbnail=0 禁用缩略图，thumbnail=1 启用缩略图
; [thumbnail]段中的 useffmpeg 表示是否调用ffmpeg生成缩略图，该方式效率较高，推荐
; useffmpeg = 1 -> 使用ffmpeg生成缩略图，推荐；useffmpeg = 0 -> 使用mpv生成缩略图，效率低，不推荐
; [thumbnail]段中的 useffmpeg 和 start 项只在 thumbnail=1 时生效
; start 项同mpv的启动参数“--start=”，详见：https://mpv.io/manual/stable/#playback-control
; [config]段的ffmpeg和ffmpeg64指定FFmpeg所在目录，即ffmpeg.exe所在目录（压缩包中的bin文件夹）
; ffmpeg64 是“.wlx64”版本读取的配置项
; FFThumb32.dll 与 FFThumb64.dll 用于获取视频缩略图，需要和 mpvLister.wlx 放在同一文件夹内
; 插件使用 FFmpeg 7 Shared 版本（解压bin文件夹，里边含有所有DLL），包含所有DLL文件：
; （下载的FFmpeg的bin文件夹内没有DLL，只有3个exe的是静态版本，请更换下载链接）
avcodec-61.dll
avdevice-61.dll
avfilter-10.dll
avformat-61.dll
avutil-59.dll
postproc-58.dll
swresample-5.dll
swscale-8.dll
（文件名必须完全相同，包括文件名中的数字）
; 如果你想要自定义编译FFmpeg 7，请至少包含如下DLL:
avcodec-61.dll
avformat-61.dll
avutil-59.dll
swscale-8.dll


; 推荐 FFmpeg 7 版本：（较完整编译，采用兼容版Rust工具链，最大程度兼容Win7）
百度网盘：
链接：https://pan.baidu.com/s/1_6bP9rYNGt_DuzvEkxYCZA?pwd=xpx6 
提取码：xpx6 
videohelp 论坛：
链接：https://forum.videohelp.com/threads/414767-ffmpeg-7-0-1-and-Windows-7#post2769089
; Win32位编译版：https://github.com/defisym/FFmpeg-Builds-Win32/releases （选择带 shared 字样的版本）
; Gyan 编译版：https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-full-shared.7z
; BtbN 编译版：https://github.com/BtbN/FFmpeg-Builds/releases （选择带 Win 和 shared 字样的版本）
; FFmpeg 是常用的音视频处理工具，可以将其添加到环境变量 PATH 中


; [output]段记录上一次JSON命令的返回值（非JSON格式的命令无返回值）
; [info]段记录特殊信息，请不要随意修改；如果不小心修改了，请清空该段让插件自动生成


; 更新本插件，通常只需要替换 mpvLister.wlx 和 mpvLister.wlx64 即可，mpvLister.ini 配置文件的改变可以参考“!HISTORY.txt”和“!Readme.txt”
; 不使用缩略图功能可以删除 FFThumb32.dll 和 FFThumb64.dll 两个文件
